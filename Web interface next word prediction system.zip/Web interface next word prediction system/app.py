import numpy as np
from flask import Flask, request, render_template
from tensorflow.keras.models import load_model
import pickle
from tensorflow.keras.preprocessing.sequence import pad_sequences

app = Flask(__name__)

# Load the pre-trained model and tokenizer
model = load_model('wordPrediction.h5')
with open('tokenizer.pkl', 'rb') as tokenizer_file:
    mytokenizer = pickle.load(tokenizer_file)

# Define the maximum sequence length
max_sequence_len = 211

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        input_text = request.form['input_text']
        predict_next_words = 1

        for _ in range(predict_next_words):
            token_list = mytokenizer.texts_to_sequences([input_text])[0]
            token_list = pad_sequences([token_list], maxlen=max_sequence_len - 1, padding='pre')
            predicted = np.argmax(model.predict(token_list), axis=-1)
            output_word = ""
            for word, index in mytokenizer.word_index.items():
                if index == predicted:
                    output_word = word
                    break
            input_text += " " + output_word

        return render_template('index.html', input_text=input_text)

if __name__ == '__main__':
    app.run(debug=True)
